
void sense_instr();

