
EXTERN uint8 evenpar[64];
EXTERN uint8 oddpar[64];
EXTERN uint8 bcdbin[64];
EXTERN uint8 binbcd[64];
