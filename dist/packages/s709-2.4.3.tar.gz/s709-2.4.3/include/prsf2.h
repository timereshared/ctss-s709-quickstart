/*
 * Parse arguments for two files,
 * one input one output,
 * specified explicitly or
 * as one base name with different extensions
 */

void parsefiles (int, char **, char *, char *, int *, int *);

