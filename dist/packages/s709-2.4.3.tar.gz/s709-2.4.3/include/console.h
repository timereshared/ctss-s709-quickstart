
int commands (FILE *);
void check_intr();
void console();
void clear();
