#define TOPLINE 1
#define CHANNELLINE 10
#define OUTPUTLINE 17

extern void clearline (void);
extern void clearscreen (void);
extern void screenposition (int , int);

